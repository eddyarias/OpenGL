
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <learnopengl/shader_s.h>

#include <iostream>

#define STB_IMAGE_IMPLEMENTATION //Add to use stb_image.h
#include <learnopengl/stb_image.h> //Add to use stb_image.h

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

int main()
{
    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Eddy Arias 1725589681", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // build and compile our shader zprogram
    // ------------------------------------
    Shader ourShader("shaders/shader_exercise8.vs", "shaders/shader_exercise8.fs");

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    float vertices[] = {
        // positions          // colors           // texture coords
             // Tri�ngulo morado
            0.4f, 0.0f, 0.0f,    0.4157f, 0.4f, 0.7843f,   0.7f, 0.5f,
            0.8f, 0.0f, 0.0f,    0.4157f, 0.4f, 0.7843f,   0.9f, 0.5f,
            0.4f, 0.4f, 0.0f,    0.4157f, 0.4f, 0.7843f,   0.7f, 0.7f,
            0.4f, 0.0f, 0.0f,    0.4157f, 0.4f, 0.7843f,   0.7f, 0.5f,
            0.4f, 0.4f, 0.0f,    0.4157f, 0.4f, 0.7843f,   0.7f, 0.7f,
            0.0f, 0.4f, 0.0f,    0.4157f, 0.4f, 0.7843f,   0.5f, 0.7f,

            // Tri�ngulo verde lima
            0.0f, 0.8f, 0.0f,    0.6f, 0.8f, 0.2f,         0.5f, 0.9f,
            0.4f, 0.4f, 0.0f,    0.6f, 0.8f, 0.2f,         0.7f, 0.7f,
            -0.4f, 0.4f, 0.0f,    0.6f, 0.8f, 0.2f,         0.3f, 0.7f,

            // Tri�ngulo NARANJA
            -0.8f, 0.0f, 0.0f,    1.0f, 0.6039f, 0.2509f,   0.1f, 0.5f,
            -0.4f, 0.0f, 0.0f,    1.0f, 0.6039f, 0.2509f,   0.3f, 0.5f,
            -0.4f, 0.4f, 0.0f,    1.0f, 0.6039f, 0.2509f,   0.3f, 0.7f,

            // Tri�ngulo celeste
            -0.4f, 0.4f, 0.0f,   0.1882f, 0.5961f, 0.9804f, 0.3f, 0.7f,
            0.0f, 0.4f, 0.0f,    0.1882f, 0.5961f, 0.9804f, 0.5f, 0.7f,
            -0.4f, 0.0f, 0.0f,   0.1882f, 0.5961f, 0.9804f, 0.3f, 0.5f,

            // Tri�ngulo verde/celeste
            0.0f, -0.4f, 0.0f,   0.0f, 0.7961f, 0.4392f,   0.5f, 0.3f,
            0.0f, 0.4f, 0.0f,    0.0f, 0.7961f, 0.4392f,   0.5f, 0.7f,
            -0.8f, -0.4f, 0.0f,   0.0f, 0.7961f, 0.4392f,   0.1f, 0.3f,

            // Tri�ngulo amarillo
            0.8f, -0.4f, 0.0f,   1.0f, 0.8039f, 0.2157f,   0.9f, 0.3f,
            0.0f, -0.4f, 0.0f,   1.0f, 0.8039f, 0.2157f,   0.5f, 0.3f,
            0.0f, 0.4f, 0.0f,   1.0f, 0.8039f, 0.2157f,   0.5f, 0.7f,

            // Tri�ngulos rosa
            -0.2f, -0.4f, 0.0f,  1.0f, 0.4118f, 0.4f,      0.4f, 0.3f,
            0.2f, -0.4f, 0.0f,  1.0f, 0.4118f, 0.4f,      0.6f, 0.3f,
            -0.2f, -0.8f, 0.0f,  1.0f, 0.4118f, 0.4f,      0.4f, 0.1f,
            0.2f, -0.4f, 0.0f,  1.0f, 0.4118f, 0.4f,      0.6f, 0.3f,
            -0.2f, -0.8f, 0.0f,  1.0f, 0.4118f, 0.4f,      0.4f, 0.1f,
            0.2f, -0.8f, 0.0f,  1.0f, 0.4118f, 0.4f,      0.6f, 0.1f,

    };
    unsigned int indices[] = {
        0, 1, 2,  // Tri�ngulo Azul 1
        3, 4, 5,  // Tri�ngulo Azul 2
        6, 7, 8,  // Tri�ngulo verde lima
        9, 10, 11, // Tri�ngulo NARANJA
        12, 13, 14, // Tri�ngulo celeste

        15, 16, 17, // Tri�ngulo verde/celeste
        18, 19, 20, // Tri�ngulo amarillo
        21, 22, 23, // Tri�ngulo rosa 1
        24, 25, 26  // Tri�ngulo rosa 2
    };

    unsigned int VBO, VAO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // color attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // texture coord attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);


    // load and create a texture 
    // -------------------------
    unsigned int texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture); // all upcoming GL_TEXTURE_2D operations now have effect on this texture object
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    int width, height, nrChannels;
    // The FileSystem::getPath(...) is part of the GitHub repository so we can find files on any IDE/platform; replace it with your own image path.
    //unsigned char* data = stbi_load(FileSystem::getPath("textures/container.jpg").c_str(), &width, &height, &nrChannels, 0);
    unsigned char* data = stbi_load("textures/texture1.jpg", &width, &height, &nrChannels, 0);

    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    unsigned int texture2;
    glGenTextures(1, &texture2);
    glBindTexture(GL_TEXTURE_2D, texture2);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    unsigned char* data2 = stbi_load("textures/texture2.jpg", &width, &height, &nrChannels, 0);
    if (data2)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data2);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture2" << std::endl;
    }
    stbi_image_free(data2);



    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        // bind Texture and send to the fragment shader sampler
        glBindTexture(GL_TEXTURE_2D, texture);

        // render container
        ourShader.use();
        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, 15, GL_UNSIGNED_INT, 0);

        // bind Texture2 and draw the other triangles
        glBindTexture(GL_TEXTURE_2D, texture2);

        // Aqu� dibujas los tri�ngulos que deben usar la segunda textura
        glDrawElements(GL_TRIANGLES, 12, GL_UNSIGNED_INT, (void*)(15 * sizeof(unsigned int))); // Ajusta para dibujar los tri�ngulos restantes

        // set the texture mix value in the shader
        float timeValue = glfwGetTime(); //tiempo de ejecucion
        float visibilyFactor = sin(timeValue) / 2.0f + 0.5f; //oscila entre 0 y 1   (es uniforme no aleatorio)
        ourShader.setFloat("visibleColor", visibilyFactor);

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}