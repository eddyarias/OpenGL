#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <learnopengl/shader_s.h>
#include <iostream>

#define STB_IMAGE_IMPLEMENTATION 
#include <learnopengl/stb_image.h>

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);

const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 800;

int main()
{
    /*Se inicia el gestor de ventanas*/
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    /*Se crea la ventana segun los parametros adecuados, ancho y alto, nombre de ventana "Primer triangulo"*/
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "B1T3 Eddy Arias Imagen 1", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);  //Establecer la ventana actual de OpenGL
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // glad: cargar todos los punteros de funciones de OpenGL
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    //Crea y toma argumentos de entrada.
    Shader ourShader("shaders/B1P3_Eddy_Arias_code_VerShader.vs", "shaders/B1P3_Eddy_Arias_code_FragShader.fs");

    float vertices[] = {
        // Posiciones        // Colores      
        //Tri�ngulos morados
        0.4f, 0.0f, 0.0f,    0.4157f, 0.4f, 0.7843f, 
        0.8f, 0.0f, 0.0f,    0.4157f, 0.4f, 0.7843f, 
        0.4f, 0.4f, 0.0f,    0.4157f, 0.4f, 0.7843f,
        0.4f, 0.0f, 0.0f,    0.4157f, 0.4f, 0.7843f,
        0.4f, 0.4f, 0.0f,    0.4157f, 0.4f, 0.7843f,
        0.0f, 0.4f, 0.0f,    0.4157f, 0.4f, 0.7843f,

        // Tri�ngulo verde lima
        0.0f, 0.8f, 0.0f,    0.6f, 0.8f, 0.2f,        
        0.4f, 0.4f, 0.0f,    0.6f, 0.8f, 0.2f,
       -0.4f, 0.4f, 0.0f,    0.6f, 0.8f, 0.2f,

        // Tri�ngulo NARANJA
       -0.8f, 0.0f, 0.0f,    1.0f, 0.6039f, 0.2509f,
       -0.4f, 0.0f, 0.0f,    1.0f, 0.6039f, 0.2509f,
       -0.4f, 0.4f, 0.0f,    1.0f, 0.6039f, 0.2509f,

       //Tri�ngulo celeste
        -0.4f, 0.4f, 0.0f,   0.1882f, 0.5961f, 0.9804f,
        0.0f, 0.4f, 0.0f,    0.1882f, 0.5961f, 0.9804f,
        -0.4f, 0.0f, 0.0f,   0.1882f, 0.5961f, 0.9804f,

       // Tri�ngulo verde/celeste
      0.0f, -0.4f, 0.0f,     0.0f, 0.7961f, 0.4392f,
       0.0f, 0.4f, 0.0f,     0.0f, 0.7961f, 0.4392f,
      -0.8f, -0.4f, 0.0f,    0.0f, 0.7961f, 0.4392f,

      // Tri�ngulo amarillo
     0.8f, -0.4f, 0.0f,      1.0f, 0.8039f, 0.2157f,
     0.0f, -0.4f, 0.0f,      1.0f, 0.8039f, 0.2157f,
      0.0f, 0.4f, 0.0f,      1.0f, 0.8039f, 0.2157f,

      // Tri�ngulos rosa
     -0.2f, -0.4f, 0.0f,     1.0f, 0.4118f, 0.4f,
      0.2f, -0.4f, 0.0f,     1.0f, 0.4118f, 0.4f,
      -0.2f, -0.8f, 0.0f,    1.0f, 0.4118f, 0.4f,
      0.2f, -0.4f, 0.0f,     1.0f, 0.4118f, 0.4f,
      -0.2f, -0.8f, 0.0f,    1.0f, 0.4118f, 0.4f,
      0.2f, -0.8f, 0.0f,     1.0f, 0.4118f, 0.4f,
    };

    //Se crea el VAO, VBO 
    unsigned int VBO, VAO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    //Aqui comienza la recopilacion de informacion del VAO
    glBindVertexArray(VAO);
    //Se a�ade el VBO al buffer
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    //Se envia los vertices en el VBO para mover los datos de la CPU a la GPU 
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    //Se describe como se debe interpretar la informacion del arreglo de vertices del VBO


    //NUEVO CAMBIAR 6 POR EL 8 PORQUE SE SALTA DE 8 EN 8
    // 
    //atributos de vertices
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    //atributos de color
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    ///NUEVO
    // texture coord attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    //NUEVO 
                // load and create a texture 
                // -------------------------
                unsigned int texture1, texture2;
                // texture 1
                // ---------
                glGenTextures(1, &texture1);
                glBindTexture(GL_TEXTURE_2D, texture1);
                // set the texture wrapping parameters
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
                // set texture filtering parameters
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                // load image, create texture and generate mipmaps
                int width, height, nrChannels;
                stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
                // The FileSystem::getPath(...) is part of the GitHub repository so we can find files on any IDE/platform; replace it with your own image path.
                unsigned char* data = stbi_load("textures/texture1.jpg", &width, &height, &nrChannels, 0);
                if (data)
                {
                    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
                    glGenerateMipmap(GL_TEXTURE_2D);
                }
                else
                {
                    std::cout << "Failed to load texture" << std::endl;
                }
                stbi_image_free(data);
                // texture 2
                // ---------
                glGenTextures(1, &texture2);
                glBindTexture(GL_TEXTURE_2D, texture2);
                // set the texture wrapping parameters
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
                // set texture filtering parameters
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                // load image, create texture and generate mipmaps
                data = stbi_load("textures/texture2.jpg", &width, &height, &nrChannels, 0);
                if (data)
                {
                    // note that the awesomeface.png has transparency and thus an alpha channel, so make sure to tell OpenGL the data type is of GL_RGBA
                    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
                    glGenerateMipmap(GL_TEXTURE_2D);
                }
                else
                {
                    std::cout << "Failed to load texture" << std::endl;
                }
                stbi_image_free(data);

                // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
                // -------------------------------------------------------------------------------------------
                ourShader.use(); // don't forget to activate/use the shader before setting uniforms!
                // either set it manually like so:
                glUniform1i(glGetUniformLocation(ourShader.ID, "texture1"), 0);
                // or set it via the texture class
                ourShader.setInt("texture2", 1);

    //Se cierra el VAO, VBO 
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    
    // render loop
    while (!glfwWindowShouldClose(window))
    {
        //Se procesa la informacion dada por dispositivos de entrada del computador
        processInput(window);

        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);               //fondo             
        glClear(GL_COLOR_BUFFER_BIT);                       //se limpia la memoria del buffer de pixeles

        /*se carga la informacion(datos) del VAO y dibuja los objetos*/
        ourShader.use();// activar el shader program para realizar c�lculos y producir el resultado visual.
        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        
        float timeValue = glfwGetTime();
        float r1 = sin(timeValue)/ 2.0f + 0.5f;
        float g1 = r1;  // Utilizando el mismo valor de r1
        float b1 = r1;  // Utilizando el mismo valor de r1

        float vx1 = sin(timeValue) / 3.0f;

        ourShader.setFloat("r1", r1);
        ourShader.setFloat("g1", g1);
        ourShader.setFloat("b1", b1);
        ourShader.setFloat("vx1", vx1);

        /*Se muestran los buffers de la ventana*/
        glfwSwapBuffers(window);
        /*Gestiona eventos que ocurran en la ventana*/
        glfwPollEvents();
    }

    //Limpian los buffers ya utilizados para limpiar la memoria
    glDeleteVertexArrays(4, &VAO);
    glDeleteBuffers(4, &VBO);

    /*Finaliza el programa*/
    glfwTerminate();
    return 0;
}
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

// glfw: cada vez que cambia el tama�o de la ventana (por el sistema operativo o el cambio de tama�o del usuario), se ejecuta esta funci�n de devoluci�n de llamada
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // aseg�rese de que la ventana gr�fica coincida con las dimensiones de la nueva ventana; tenga en cuenta que el ancho y el alto ser�n significativamente mayores que los especificados en las pantallas retina.
    glViewport(0, 0, width, height);
}